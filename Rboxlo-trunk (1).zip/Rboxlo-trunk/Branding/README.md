# Rboxlo.Branding

This folder contains Rboxlo's official branding and artwork.

Some items here are parodies of past or present Roblox logos. Our parody of those logos fall under fair use.

## Fair Use
Under Section 107 of the Copyright Act 1976, allowance is made for "fair use" for purposes such as criticism, comment, news reporting, teaching, scholarship and research. Fair use is a use permitted by copyright statute that might otherwise be infringing. Non-profit, educational or personal use tips the balance in favor of fair use.