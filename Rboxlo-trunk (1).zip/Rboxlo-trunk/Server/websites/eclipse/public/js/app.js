window.rboxlo = []

function loginSubmit(token) {
    document.getElementById("login-form").submit()
}