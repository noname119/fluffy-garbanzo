# Rboxlo.Server

This is the Rboxlo server. It is the internet part of the Rboxlo application. Serves the API, user-facing website, moderation panel, etc.