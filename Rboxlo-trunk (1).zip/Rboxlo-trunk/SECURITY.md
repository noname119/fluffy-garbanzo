# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.0.0   | :white_check_mark: |

## Reporting a Vulnerability

Simply [create an issue](https://github.com/lightbulblighter/Rboxlo/issues/new) specifying the vulnerability, proof of concept, and optionally real-world scenarios where it could be abused in order to better illustrate the importance of the vulnerability.
